﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormInputPenjualan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormInputPenjualan))
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripLabel()
        Me.cbPrinter = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.cbStatusPiutang = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.bHapusRecordGrid = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel()
        Me.tTotalItem = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel()
        Me.tDiskon = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel8 = New System.Windows.Forms.ToolStripLabel()
        Me.tItem = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.tTerbilangKembalian = New System.Windows.Forms.TextBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.tTerbilang = New System.Windows.Forms.TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.tKembalian = New System.Windows.Forms.TextBox()
        Me.tPembayaran = New System.Windows.Forms.TextBox()
        Me.ckBesarFaktur = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tSubTotalItem = New System.Windows.Forms.TextBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.ckMiniFaktur = New System.Windows.Forms.CheckBox()
        Me.tTotalBayar = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tStokAwal = New System.Windows.Forms.TextBox()
        Me.tStokAkhir = New System.Windows.Forms.TextBox()
        Me.ckBarcode = New System.Windows.Forms.CheckBox()
        Me.bOk = New System.Windows.Forms.Button()
        Me.tNamaBarang = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tIDBarang = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tIDPenjualan = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tIDPelanggan = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tHargaJual = New System.Windows.Forms.TextBox()
        Me.tNamaPelanggan = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.TutupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BatalSemuaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BatalItemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmPenjualan = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GridDataInputPenjualan = New System.Windows.Forms.DataGridView()
        Me.ID_Transaksi = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ID_Pelanggan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Pelanggan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ID_Barang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Nama_Barang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Harga_Jual = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Diskon = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sub_Total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Qty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ToolStrip2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.cmPenjualan.SuspendLayout()
        CType(Me.GridDataInputPenjualan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip2.ImageScalingSize = New System.Drawing.Size(30, 30)
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.cbPrinter, Me.ToolStripSeparator2, Me.cbStatusPiutang, Me.ToolStripSeparator3})
        Me.ToolStrip2.Location = New System.Drawing.Point(3, 16)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(604, 33)
        Me.ToolStrip2.TabIndex = 0
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(113, 30)
        Me.ToolStripButton1.Text = "&Pilih Printer :"
        '
        'cbPrinter
        '
        Me.cbPrinter.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbPrinter.Name = "cbPrinter"
        Me.cbPrinter.Size = New System.Drawing.Size(175, 33)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 33)
        '
        'cbStatusPiutang
        '
        Me.cbStatusPiutang.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbStatusPiutang.Items.AddRange(New Object() {"Tunai", "Hutang"})
        Me.cbStatusPiutang.Name = "cbStatusPiutang"
        Me.cbStatusPiutang.Size = New System.Drawing.Size(85, 33)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 33)
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ToolStripLabel5.Image = CType(resources.GetObject("ToolStripLabel5.Image"), System.Drawing.Image)
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(162, 22)
        Me.ToolStripLabel5.Text = "&F3 = Tambah Record 1"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'bHapusRecordGrid
        '
        Me.bHapusRecordGrid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.bHapusRecordGrid.Image = CType(resources.GetObject("bHapusRecordGrid.Image"), System.Drawing.Image)
        Me.bHapusRecordGrid.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.bHapusRecordGrid.Name = "bHapusRecordGrid"
        Me.bHapusRecordGrid.Size = New System.Drawing.Size(152, 22)
        Me.bHapusRecordGrid.Text = "&F2 = Hapus Record 1"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ToolStripLabel1.Image = CType(resources.GetObject("ToolStripLabel1.Image"), System.Drawing.Image)
        Me.ToolStripLabel1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(120, 22)
        Me.ToolStripLabel1.Text = "&F1 = Pelanggan"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.ToolStripSeparator6, Me.bHapusRecordGrid, Me.ToolStripSeparator10, Me.ToolStripLabel5, Me.ToolStripSeparator9, Me.ToolStripLabel2, Me.ToolStripSeparator5, Me.ToolStripLabel3, Me.ToolStripSeparator7, Me.ToolStripLabel4, Me.ToolStripSeparator8, Me.ToolStripLabel6, Me.tTotalItem, Me.ToolStripSeparator11, Me.ToolStripLabel7, Me.tDiskon, Me.ToolStripSeparator12, Me.ToolStripLabel8, Me.tItem, Me.ToolStripSeparator13})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 16)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1267, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ToolStripLabel2.Image = CType(resources.GetObject("ToolStripLabel2.Image"), System.Drawing.Image)
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripLabel2.Text = "&F12 = Qty Lebih Dari 1"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.ForeColor = System.Drawing.Color.Teal
        Me.ToolStripLabel3.Image = CType(resources.GetObject("ToolStripLabel3.Image"), System.Drawing.Image)
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(130, 22)
        Me.ToolStripLabel3.Text = "F8 = Aktif Diskon"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.ForeColor = System.Drawing.Color.Teal
        Me.ToolStripLabel4.Image = CType(resources.GetObject("ToolStripLabel4.Image"), System.Drawing.Image)
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(124, 22)
        Me.ToolStripLabel4.Text = "F9 = Aktif Harga"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(66, 22)
        Me.ToolStripLabel6.Text = "&Item Qty :"
        '
        'tTotalItem
        '
        Me.tTotalItem.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTotalItem.Name = "tTotalItem"
        Me.tTotalItem.Size = New System.Drawing.Size(50, 25)
        Me.tTotalItem.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(56, 22)
        Me.ToolStripLabel7.Text = "Diskon :"
        '
        'tDiskon
        '
        Me.tDiskon.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tDiskon.Name = "tDiskon"
        Me.tDiskon.Size = New System.Drawing.Size(75, 25)
        Me.tDiskon.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel8
        '
        Me.ToolStripLabel8.Name = "ToolStripLabel8"
        Me.ToolStripLabel8.Size = New System.Drawing.Size(41, 22)
        Me.ToolStripLabel8.Text = "&Item :"
        '
        'tItem
        '
        Me.tItem.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tItem.Name = "tItem"
        Me.tItem.Size = New System.Drawing.Size(50, 25)
        Me.tItem.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 25)
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(615, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(102, 18)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "KEMBALIAN :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(5, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(120, 18)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "TOTAL BAYAR :"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.ToolStrip1)
        Me.GroupBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GroupBox7.Location = New System.Drawing.Point(6, 644)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(1273, 50)
        Me.GroupBox7.TabIndex = 32
        Me.GroupBox7.TabStop = False
        '
        'tTerbilangKembalian
        '
        Me.tTerbilangKembalian.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTerbilangKembalian.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.tTerbilangKembalian.Location = New System.Drawing.Point(723, 11)
        Me.tTerbilangKembalian.Name = "tTerbilangKembalian"
        Me.tTerbilangKembalian.Size = New System.Drawing.Size(541, 25)
        Me.tTerbilangKembalian.TabIndex = 1
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label9)
        Me.GroupBox10.Controls.Add(Me.Label8)
        Me.GroupBox10.Controls.Add(Me.tTerbilangKembalian)
        Me.GroupBox10.Controls.Add(Me.tTerbilang)
        Me.GroupBox10.Location = New System.Drawing.Point(6, 603)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(1273, 42)
        Me.GroupBox10.TabIndex = 31
        Me.GroupBox10.TabStop = False
        '
        'tTerbilang
        '
        Me.tTerbilang.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTerbilang.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.tTerbilang.Location = New System.Drawing.Point(127, 11)
        Me.tTerbilang.Name = "tTerbilang"
        Me.tTerbilang.Size = New System.Drawing.Size(483, 25)
        Me.tTerbilang.TabIndex = 0
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.tKembalian)
        Me.GroupBox9.Controls.Add(Me.tPembayaran)
        Me.GroupBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GroupBox9.Location = New System.Drawing.Point(623, 542)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(656, 61)
        Me.GroupBox9.TabIndex = 30
        Me.GroupBox9.TabStop = False
        '
        'tKembalian
        '
        Me.tKembalian.BackColor = System.Drawing.SystemColors.HotTrack
        Me.tKembalian.Font = New System.Drawing.Font("Arial Unicode MS", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tKembalian.ForeColor = System.Drawing.SystemColors.Info
        Me.tKembalian.Location = New System.Drawing.Point(324, 11)
        Me.tKembalian.Name = "tKembalian"
        Me.tKembalian.Size = New System.Drawing.Size(323, 44)
        Me.tKembalian.TabIndex = 10
        Me.tKembalian.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tPembayaran
        '
        Me.tPembayaran.BackColor = System.Drawing.SystemColors.HotTrack
        Me.tPembayaran.Font = New System.Drawing.Font("Arial Unicode MS", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tPembayaran.ForeColor = System.Drawing.SystemColors.Info
        Me.tPembayaran.Location = New System.Drawing.Point(6, 11)
        Me.tPembayaran.Name = "tPembayaran"
        Me.tPembayaran.Size = New System.Drawing.Size(314, 44)
        Me.tPembayaran.TabIndex = 9
        Me.tPembayaran.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ckBesarFaktur
        '
        Me.ckBesarFaktur.AutoSize = True
        Me.ckBesarFaktur.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckBesarFaktur.Location = New System.Drawing.Point(403, 21)
        Me.ckBesarFaktur.Name = "ckBesarFaktur"
        Me.ckBesarFaktur.Size = New System.Drawing.Size(95, 22)
        Me.ckBesarFaktur.TabIndex = 1
        Me.ckBesarFaktur.Text = "Print Faktur"
        Me.ckBesarFaktur.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.tSubTotalItem)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 436)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(611, 106)
        Me.GroupBox4.TabIndex = 26
        Me.GroupBox4.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 18)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Sub.Total/Item :"
        '
        'tSubTotalItem
        '
        Me.tSubTotalItem.BackColor = System.Drawing.SystemColors.HotTrack
        Me.tSubTotalItem.Font = New System.Drawing.Font("Arial Unicode MS", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tSubTotalItem.ForeColor = System.Drawing.Color.White
        Me.tSubTotalItem.Location = New System.Drawing.Point(6, 28)
        Me.tSubTotalItem.Name = "tSubTotalItem"
        Me.tSubTotalItem.Size = New System.Drawing.Size(599, 72)
        Me.tSubTotalItem.TabIndex = 9
        Me.tSubTotalItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.ckMiniFaktur)
        Me.GroupBox8.Controls.Add(Me.ckBesarFaktur)
        Me.GroupBox8.Controls.Add(Me.ToolStrip2)
        Me.GroupBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GroupBox8.Location = New System.Drawing.Point(6, 542)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(610, 61)
        Me.GroupBox8.TabIndex = 29
        Me.GroupBox8.TabStop = False
        '
        'ckMiniFaktur
        '
        Me.ckMiniFaktur.AutoSize = True
        Me.ckMiniFaktur.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckMiniFaktur.Location = New System.Drawing.Point(504, 22)
        Me.ckMiniFaktur.Name = "ckMiniFaktur"
        Me.ckMiniFaktur.Size = New System.Drawing.Size(92, 22)
        Me.ckMiniFaktur.TabIndex = 2
        Me.ckMiniFaktur.Text = "Mini Faktur"
        Me.ckMiniFaktur.UseVisualStyleBackColor = True
        '
        'tTotalBayar
        '
        Me.tTotalBayar.BackColor = System.Drawing.SystemColors.HotTrack
        Me.tTotalBayar.Font = New System.Drawing.Font("Arial Unicode MS", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTotalBayar.ForeColor = System.Drawing.Color.White
        Me.tTotalBayar.Location = New System.Drawing.Point(6, 28)
        Me.tTotalBayar.Name = "tTotalBayar"
        Me.tTotalBayar.Size = New System.Drawing.Size(645, 72)
        Me.tTotalBayar.TabIndex = 10
        Me.tTotalBayar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.tTotalBayar)
        Me.GroupBox5.Location = New System.Drawing.Point(623, 436)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(656, 106)
        Me.GroupBox5.TabIndex = 27
        Me.GroupBox5.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 18)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Total Bayar :"
        '
        'tStokAwal
        '
        Me.tStokAwal.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tStokAwal.Location = New System.Drawing.Point(412, 31)
        Me.tStokAwal.Name = "tStokAwal"
        Me.tStokAwal.Size = New System.Drawing.Size(72, 25)
        Me.tStokAwal.TabIndex = 17
        Me.tStokAwal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tStokAkhir
        '
        Me.tStokAkhir.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tStokAkhir.Location = New System.Drawing.Point(485, 31)
        Me.tStokAkhir.Name = "tStokAkhir"
        Me.tStokAkhir.Size = New System.Drawing.Size(69, 25)
        Me.tStokAkhir.TabIndex = 16
        Me.tStokAkhir.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ckBarcode
        '
        Me.ckBarcode.AutoSize = True
        Me.ckBarcode.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ckBarcode.Location = New System.Drawing.Point(561, 9)
        Me.ckBarcode.Name = "ckBarcode"
        Me.ckBarcode.Size = New System.Drawing.Size(75, 22)
        Me.ckBarcode.TabIndex = 14
        Me.ckBarcode.Text = "Barcode"
        Me.ckBarcode.UseVisualStyleBackColor = True
        '
        'bOk
        '
        Me.bOk.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bOk.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bOk.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.bOk.Location = New System.Drawing.Point(561, 32)
        Me.bOk.Name = "bOk"
        Me.bOk.Size = New System.Drawing.Size(75, 23)
        Me.bOk.TabIndex = 13
        Me.bOk.Text = "OK"
        Me.bOk.UseVisualStyleBackColor = True
        '
        'tNamaBarang
        '
        Me.tNamaBarang.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tNamaBarang.Location = New System.Drawing.Point(177, 31)
        Me.tNamaBarang.Name = "tNamaBarang"
        Me.tNamaBarang.Size = New System.Drawing.Size(229, 25)
        Me.tNamaBarang.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(174, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 18)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Nama Barang"
        '
        'tIDBarang
        '
        Me.tIDBarang.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tIDBarang.Location = New System.Drawing.Point(9, 31)
        Me.tIDBarang.Name = "tIDBarang"
        Me.tIDBarang.Size = New System.Drawing.Size(167, 25)
        Me.tIDBarang.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(87, 18)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Kode. Barang"
        '
        'tIDPenjualan
        '
        Me.tIDPenjualan.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tIDPenjualan.Location = New System.Drawing.Point(9, 30)
        Me.tIDPenjualan.Name = "tIDPenjualan"
        Me.tIDPenjualan.ReadOnly = True
        Me.tIDPenjualan.Size = New System.Drawing.Size(184, 25)
        Me.tIDPenjualan.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 18)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "ID.Penjualan"
        '
        'tIDPelanggan
        '
        Me.tIDPelanggan.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tIDPelanggan.Location = New System.Drawing.Point(8, 32)
        Me.tIDPelanggan.Name = "tIDPelanggan"
        Me.tIDPelanggan.Size = New System.Drawing.Size(187, 25)
        Me.tIDPelanggan.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 18)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "ID. Pelanggan"
        '
        'tHargaJual
        '
        Me.tHargaJual.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tHargaJual.Location = New System.Drawing.Point(177, 31)
        Me.tHargaJual.Name = "tHargaJual"
        Me.tHargaJual.Size = New System.Drawing.Size(94, 25)
        Me.tHargaJual.TabIndex = 15
        Me.tHargaJual.Visible = False
        '
        'tNamaPelanggan
        '
        Me.tNamaPelanggan.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tNamaPelanggan.Location = New System.Drawing.Point(196, 32)
        Me.tNamaPelanggan.Name = "tNamaPelanggan"
        Me.tNamaPelanggan.Size = New System.Drawing.Size(220, 25)
        Me.tNamaPelanggan.TabIndex = 10
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.tNamaPelanggan)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.tIDPelanggan)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(208, 1)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(423, 63)
        Me.GroupBox2.TabIndex = 24
        Me.GroupBox2.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(194, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 18)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Nama Pelanggan"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.tStokAwal)
        Me.GroupBox3.Controls.Add(Me.tStokAkhir)
        Me.GroupBox3.Controls.Add(Me.ckBarcode)
        Me.GroupBox3.Controls.Add(Me.bOk)
        Me.GroupBox3.Controls.Add(Me.tNamaBarang)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.tIDBarang)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.tHargaJual)
        Me.GroupBox3.Location = New System.Drawing.Point(635, 1)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(646, 63)
        Me.GroupBox3.TabIndex = 25
        Me.GroupBox3.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tIDPenjualan)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(198, 63)
        Me.GroupBox1.TabIndex = 23
        Me.GroupBox1.TabStop = False
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(148, 6)
        '
        'TutupToolStripMenuItem
        '
        Me.TutupToolStripMenuItem.Image = CType(resources.GetObject("TutupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TutupToolStripMenuItem.Name = "TutupToolStripMenuItem"
        Me.TutupToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.TutupToolStripMenuItem.Text = "Tutup"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(148, 6)
        '
        'BatalSemuaToolStripMenuItem
        '
        Me.BatalSemuaToolStripMenuItem.Image = CType(resources.GetObject("BatalSemuaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BatalSemuaToolStripMenuItem.Name = "BatalSemuaToolStripMenuItem"
        Me.BatalSemuaToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.BatalSemuaToolStripMenuItem.Text = "Batal Semua"
        '
        'BatalItemToolStripMenuItem
        '
        Me.BatalItemToolStripMenuItem.Image = CType(resources.GetObject("BatalItemToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BatalItemToolStripMenuItem.Name = "BatalItemToolStripMenuItem"
        Me.BatalItemToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.BatalItemToolStripMenuItem.Text = "Batal Item"
        '
        'cmPenjualan
        '
        Me.cmPenjualan.Font = New System.Drawing.Font("Arial Unicode MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmPenjualan.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BatalItemToolStripMenuItem, Me.BatalSemuaToolStripMenuItem, Me.ToolStripSeparator1, Me.TutupToolStripMenuItem, Me.ToolStripSeparator4})
        Me.cmPenjualan.Name = "cmPenjualan"
        Me.cmPenjualan.Size = New System.Drawing.Size(152, 82)
        '
        'GridDataInputPenjualan
        '
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle27.Font = New System.Drawing.Font("Arial Unicode MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.GridDataInputPenjualan.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle27
        Me.GridDataInputPenjualan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridDataInputPenjualan.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ID_Transaksi, Me.ID_Pelanggan, Me.Pelanggan, Me.ID_Barang, Me.Nama_Barang, Me.Harga_Jual, Me.Diskon, Me.Sub_Total, Me.Qty})
        Me.GridDataInputPenjualan.ContextMenuStrip = Me.cmPenjualan
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle32.Font = New System.Drawing.Font("Arial Unicode MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.GridDataInputPenjualan.DefaultCellStyle = DataGridViewCellStyle32
        Me.GridDataInputPenjualan.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridDataInputPenjualan.Location = New System.Drawing.Point(3, 16)
        Me.GridDataInputPenjualan.Name = "GridDataInputPenjualan"
        Me.GridDataInputPenjualan.Size = New System.Drawing.Size(1269, 354)
        Me.GridDataInputPenjualan.TabIndex = 0
        '
        'ID_Transaksi
        '
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ID_Transaksi.DefaultCellStyle = DataGridViewCellStyle28
        Me.ID_Transaksi.HeaderText = "ID.Transaksi"
        Me.ID_Transaksi.Name = "ID_Transaksi"
        Me.ID_Transaksi.ReadOnly = True
        Me.ID_Transaksi.Width = 125
        '
        'ID_Pelanggan
        '
        Me.ID_Pelanggan.HeaderText = ""
        Me.ID_Pelanggan.MinimumWidth = 2
        Me.ID_Pelanggan.Name = "ID_Pelanggan"
        Me.ID_Pelanggan.ReadOnly = True
        Me.ID_Pelanggan.Width = 2
        '
        'Pelanggan
        '
        Me.Pelanggan.HeaderText = "Nama Pelanggan"
        Me.Pelanggan.Name = "Pelanggan"
        Me.Pelanggan.ReadOnly = True
        Me.Pelanggan.Width = 175
        '
        'ID_Barang
        '
        Me.ID_Barang.HeaderText = "ID.Barang"
        Me.ID_Barang.MinimumWidth = 2
        Me.ID_Barang.Name = "ID_Barang"
        Me.ID_Barang.ReadOnly = True
        Me.ID_Barang.Width = 180
        '
        'Nama_Barang
        '
        Me.Nama_Barang.HeaderText = "Nama Barang"
        Me.Nama_Barang.Name = "Nama_Barang"
        Me.Nama_Barang.ReadOnly = True
        Me.Nama_Barang.Width = 240
        '
        'Harga_Jual
        '
        DataGridViewCellStyle29.Format = "N0"
        DataGridViewCellStyle29.NullValue = Nothing
        Me.Harga_Jual.DefaultCellStyle = DataGridViewCellStyle29
        Me.Harga_Jual.HeaderText = "Harga Barang"
        Me.Harga_Jual.Name = "Harga_Jual"
        Me.Harga_Jual.Width = 150
        '
        'Diskon
        '
        Me.Diskon.HeaderText = "Diskon"
        Me.Diskon.Name = "Diskon"
        Me.Diskon.Width = 123
        '
        'Sub_Total
        '
        DataGridViewCellStyle30.Format = "N0"
        DataGridViewCellStyle30.NullValue = Nothing
        Me.Sub_Total.DefaultCellStyle = DataGridViewCellStyle30
        Me.Sub_Total.HeaderText = "Sub.Total"
        Me.Sub_Total.Name = "Sub_Total"
        Me.Sub_Total.ReadOnly = True
        Me.Sub_Total.Width = 150
        '
        'Qty
        '
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Qty.DefaultCellStyle = DataGridViewCellStyle31
        Me.Qty.HeaderText = "Qty"
        Me.Qty.Name = "Qty"
        Me.Qty.Width = 65
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.GridDataInputPenjualan)
        Me.GroupBox6.Location = New System.Drawing.Point(6, 63)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(1275, 373)
        Me.GroupBox6.TabIndex = 28
        Me.GroupBox6.TabStop = False
        '
        'DataGridViewTextBoxColumn1
        '
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle19
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID.Transaksi"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = ""
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 2
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 2
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Nama Pelanggan"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 200
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "ID..Barang"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 2
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 180
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Nama Barang"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 240
        '
        'DataGridViewTextBoxColumn6
        '
        DataGridViewCellStyle24.Format = "N0"
        DataGridViewCellStyle24.NullValue = Nothing
        Me.DataGridViewTextBoxColumn6.DefaultCellStyle = DataGridViewCellStyle24
        Me.DataGridViewTextBoxColumn6.HeaderText = "Harga Barang"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 145
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Diskon"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 120
        '
        'DataGridViewTextBoxColumn8
        '
        DataGridViewCellStyle33.Format = "N0"
        DataGridViewCellStyle33.NullValue = Nothing
        Me.DataGridViewTextBoxColumn8.DefaultCellStyle = DataGridViewCellStyle33
        Me.DataGridViewTextBoxColumn8.HeaderText = "Sub.Total"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 145
        '
        'DataGridViewTextBoxColumn9
        '
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn9.DefaultCellStyle = DataGridViewCellStyle34
        Me.DataGridViewTextBoxColumn9.HeaderText = "Qty"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 65
        '
        'FormInputPenjualan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox6)
        Me.Name = "FormInputPenjualan"
        Me.Text = "FormInputPenjualan"
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.cmPenjualan.ResumeLayout(False)
        CType(Me.GridDataInputPenjualan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents cbPrinter As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cbStatusPiutang As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel5 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents bHapusRecordGrid As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel6 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tTotalItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel7 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tDiskon As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel8 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents tItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents tTerbilangKembalian As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents tTerbilang As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents tKembalian As System.Windows.Forms.TextBox
    Friend WithEvents tPembayaran As System.Windows.Forms.TextBox
    Friend WithEvents ckBesarFaktur As System.Windows.Forms.CheckBox
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tSubTotalItem As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents ckMiniFaktur As System.Windows.Forms.CheckBox
    Friend WithEvents tTotalBayar As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tStokAwal As System.Windows.Forms.TextBox
    Friend WithEvents tStokAkhir As System.Windows.Forms.TextBox
    Friend WithEvents ckBarcode As System.Windows.Forms.CheckBox
    Friend WithEvents bOk As System.Windows.Forms.Button
    Friend WithEvents tNamaBarang As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents tIDBarang As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents tIDPenjualan As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tIDPelanggan As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tHargaJual As System.Windows.Forms.TextBox
    Friend WithEvents tNamaPelanggan As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TutupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BatalSemuaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BatalItemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmPenjualan As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sub_Total As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Diskon As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Harga_Jual As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Nama_Barang As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ID_Barang As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Pelanggan As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ID_Pelanggan As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ID_Transaksi As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GridDataInputPenjualan As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
End Class
